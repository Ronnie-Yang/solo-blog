title: Docker系列—02、Docker的安装与使用
date: '2019-11-15 12:34:58'
updated: '2019-11-15 12:46:14'
tags: [Docker]
permalink: /Docker-study-02
---
![](https://gss2.bdstatic.com/9fo3dSag_xI4khGkpoWK1HF6hhy/baike/crop%3D0%2C156%2C1354%2C894%3Bc0%3Dbaike180%2C5%2C5%2C180%2C60/sign=c97c7c9b9b13b07ea9f20a4831e7bd12/f703738da977391281957edbf0198618377ae2dd.jpg) 

# O、前言
前一篇我们认识了什么是 Docker，了解了 Docker 的架构和原理。光说不练假把式，那么接下来我们就一起来学习一下 Docker 的使用吧。

# 一、Docker安装
要想使用 Docker，当然要先安装 Docker 啦。建议在linux环境下安装Docker，window环境搭建比较复杂且容易出错，使用Centos7+yum来安装Docker环境很方便。

1、Docker 要求 CentOS 系统的内核版本高于 3.10 ，查看本页面的前提条件来验证你的CentOS 版本是否支持 Docker 。

通过 uname -r 命令查看你当前的内核版本。
```shell
uname -r
```
2、使用 root 权限登录 Centos。确保 yum 包更新到最新。
```shell
sudo yum update
```
3、卸载旧版本(如果安装过旧版本的话)。
```shell
sudo yum remove docker  docker-common docker-selinux docker-engine
```
4、安装需要的软件包， yum-util 提供yum-config-manager功能，另外两个是devicemapper驱动依赖的。
```shell
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```
5、可以查看所有仓库中所有docker版本，并选择特定版本安装。
```shell
yum list docker --showduplicates | sort -r
```
6、安装Docker
```shell
sudo yum install docker
```
7、启动并加入开机启动
```shell
sudo systemctl start docker
sudo systemctl enable docker
```
8、验证安装是否成功(有client和service两部分表示docker安装启动都成功了)。
```shell
docker version
```

# 二、Docker世界的Hello World
下面，我们通过最简单的 image 文件”hello world”，感受一下 Docker。

因为国内连接 Docker 的官方仓库很慢，因此我们在日常使用中会使用Docker 中国加速器。通过 Docker 官方镜像加速，中国区用户能够快速访问最流行的 Docker 镜像。该镜像托管于中国大陆，本地用户现在将会享受到更快的下载速度和更强的稳定性，从而能够更敏捷地开发和交付 Docker 化应用。

Docker 中国官方镜像加速可通过registry.docker-cn.com访问。该镜像库只包含流行的公有镜像，私有镜像仍需要从美国镜像库中拉取。

修改系统中docker对应的配置文件即可，如下：
```shell
vi  /etc/docker/daemon.json
#添加后
{
    "registry-mirrors": ["https://registry.docker-cn.com"],
    "live-restore": true
}
```
运行下面的命令，将 image 文件从仓库抓取到本地。
```shell
docker pull library/hello-world
```
上面代码中，docker image pull是抓取 image 文件的命令。library/hello-world是 image 文件在仓库里面的位置，其中library是 image 文件所在的组，hello-world是 image 文件的名字。
```shell
docker images
```
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190515185659781.png)
现在，运行这个 image 文件。
```shell
docker run hello-world

#显示结果
Hello from Docker!
This message shows that your installation appears to be working correctly.
...
```

输出这段提示以后，hello world就会停止运行，容器自动终止。有些容器不会自动终止，因为提供的是服务，比如Mysql镜像等。

# 三、常用命令
除了以上我们使用的Docker命令外，Docker还有一些其它常用的命令。

### 1、从远程仓库拉取docker镜像。
```shell
docker pull image_name
```
### 2、 查看宿主机上的镜像，Docker镜像保存在/var/lib/docker目录下:
```shell
docker images
```
### 3、删除宿主机上的镜像，前提是这个镜像不是其他镜像的基础镜像，也没有用这个镜像启动容器，才能删除成功。
```shell
docker rmi  docker.io/tomcat:7.0.77-jre7   或者  docker rmi b39c68b7af30
```
### 4、查看当前有哪些容器正在运行
```shell
docker ps
```
### 5、查看所有容器
```shell
docker ps -a
```
### 6、启动、停止、重启容器命令：
```shell
docker start container_name/container_id
docker stop container_name/container_id
docker restart container_name/container_id
```
### 7、后台启动一个容器后，如果想进入到这个容器，可以使用attach命令：
```shell
docker attach container_name/container_id
```
### 8、删除容器
```shell
docker rm container_name/container_id
```
### 9、删除所有停止的容器：
```shell
docker rm $(docker ps -a -q)
```
### 10、查看当前系统Docker信息
```shell
docker info
```
# 四、总结
安装好了 Docker，运行了第一个 Docker 的容器，也学习了一些基本的 Docker 常用命令，是不是感觉 Docker 用起来很简单、很方便啊。这就 是 Docker 的特点，操作简单，容易上手。

有了环境，知道了基本用法，接下来我们就可以愉快的深入研究 Docker 了。
