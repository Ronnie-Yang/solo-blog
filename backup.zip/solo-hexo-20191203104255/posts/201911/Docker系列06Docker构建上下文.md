title: Docker系列—06、Docker 构建上下文
date: '2019-11-28 10:13:03'
updated: '2019-11-29 10:28:01'
tags: [Docker]
permalink: /Docker-study-06
---
![](https://gss2.bdstatic.com/9fo3dSag_xI4khGkpoWK1HF6hhy/baike/crop%3D0%2C156%2C1354%2C894%3Bc0%3Dbaike180%2C5%2C5%2C180%2C60/sign=c97c7c9b9b13b07ea9f20a4831e7bd12/f703738da977391281957edbf0198618377ae2dd.jpg)

# O、前言
在 [Docker系列—04、使用 DockerFile 定制镜像](http://www.yanggongzi.top/Docker-study-04) 这篇文章中，我们学习了如何定制镜像，在最后一步构建镜像的时候我们使用了这样的一条命令：
```
# docker build -t nginx:v3 .
```
不知道大家有没有注意到这条命令最后的 `.`，这个点涉及到的知识点就是我们这一篇要学习的 Docker 构建上下文。

好了，话不多说，就让我们一起来看什么是 Docker 构建上下文吧。

# 一、对Docker 构建上下文的误解

通过前面的学习，我们都知道，构建一个 Docker 镜像非常简单，大家一般都会这么做（当然这么做是完全正确的）：
* 跳到 Dockerfile 所在目录
* 执行 docker build 构建命令:`docker build -t <imageName:imageTag> .`

通过上面的操作，很容易形成下面的两个的理解误区：
1. docker build 后面的 . 为 Dockerfile 所在的目录
2. Dockerfile 文件名 必须为 Dockerfile

其实上面这种理解是错误的，要想准确理解其含义，首先我们需要先了解下 Docker 的架构和 docker build 的工作原理。

# 二、重新理解 Docker 的架构
在第一篇 [Docker系列—01、Docker的简介与架构](http://www.yanggongzi.top/Docker-study-01#b3_solo_h1_9) 的时候，我们就介绍过 Docker 的架构，这里我们针对 Docker 使用的 C/S 架构模型再深入认识一下 Docker 的架构。
 
我们知道 Docker 是一个典型的 C/S 架构的应用，分为 Docker 客户端（即平时敲的 docker 命令） Docker 服务端（dockerd 守护进程）。

Docker 客户端通过 REST API 和服务端进行交互，docker 客户端每发送一条指令，底层都会转化成 REST API 调用的形式发送给服务端，服务端处理客户端发送的请求并给出响应。

Docker 镜像的构建、容器创建、容器运行等工作都是 Docker 服务端来完成的，Docker 客户端只是承担发送指令的角色。

Docker 客户端和服务端可以在同一个宿主机，也可以在不同的宿主机，如果在同一个宿主机的话，Docker 客户端默认通过 UNIX 套接字(/var/run/docker.sock)和服务端通信。

![null](https://img-blog.csdnimg.cn/2019021720142533.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpYW5naGFvaGFv,size_16,color_FFFFFF,t_70)

# 三、理解 docker build 的工作原理
理解了 Docker 的架构就很容易理解 docker build 构建镜像的工作原理了。docker build 构建镜像的流程大概如下：
1. 执行 `docker build -t <imageName:imageTag> .` ;
2. Docker 客户端会将构建命令后面指定的路径(.)下的所有文件打包成一个 tar 包，发送给 Docker 服务端;
3. Docker 服务端收到客户端发送的 tar 包，然后解压，根据 Dockerfile 里面的指令进行镜像的分层构建。

# 四、正确理解 Docker 构建上下文

了解了 Docker 的架构和镜像构建的工作原理后，Docker 构建上下文也就容易理解了。Docker 构建上下文就是 Docker 客户端上传给服务端的 tar 文件解压后的内容，也即 docker build 命令行后面指定路径下的文件。

Docker 镜像的构建是在远程服务端进行的，所以客户端需要把构建所需要的文件传输给服务端。服务端以客户端发送的文件为上下文，也就是说 Dockerfile 中指令的工作目录就是服务端解压客户端传输的 tar 包的路径。

关于 docker build 指令的两点重要的说明：
1. 如果构建镜像时没有明确指定 Dockerfile，那么 Docker 客户端默认在构建镜像时指定的上下文路径下找名字为 Dockerfile 的构建文件；
2. Dockerfile 可以不在构建上下文路径下，此时需要构建时通过 -f 参数明确指定使用哪个构建文件，并且名称可以自己任意命名。

下面通过具体的实例来理解下:

首先创建一个简单的 demo 工程，工程结构如下：
```
helloworld-app
├── Dockerfile
└── docker
    ├── app-1.0-SNAPSHOT.jar
    ├── hello.txt
    └── html
        └── index.html
```

Dockerfile 内容：
```
FROM busybox
COPY hello.txt .
COPY html/index.html .
```

## 实践1：直接进入 helloworld-app 目录进行镜像构建，以 docker 目录为构建上下文
```
[root@yanggongzi ~]# docker build -t hello-app:1.0 docker
unable to prepare context: unable to evaluate symlinks in Dockerfile path: lstat /Users/haohao/opensource/helloworld-app/docker/Dockerfile: no such file or directory
```
可以看出默认 docker 客户端从 docker 构建上下文路径下找名字为 Dockerfile 的构建文件。

## 实践2：明确指定 Dockerfile 文件进行镜像构建，还是以 docker 目录为构建上下文
```
[root@yanggongzi ~]# docker build -f Dockerfile -t hello-app:1.0 docker                                                                                 
Sending build context to Docker daemon  96.61MB
Step 1/3 : FROM busybox
 ---> d8233ab899d4
Step 2/3 : COPY hello.txt .
 ---> 3305fc373120
Step 3/3 : COPY html/index.html .
 ---> efdefc4e6eb2
Successfully built efdefc4e6eb2
Successfully tagged hello-app:1.0
```
从输出结果可以得知：

1. 构建镜像时客户端会先给服务端发送构建上下路径下的内容（即 docker 目录下的文件）；
2. Dockerfile 可以不在构建上下文路径下；
3. Dockerfile 中指令的工作目录是服务端解压客户端传输的 tar 包的路径。

## 实践3：以当前目录为构建上下文路径
```
[root@yanggongzi ~]# ls
Dockerfile docker
[root@yanggongzi ~]# docker build -t hello-app:2.0 .
Sending build context to Docker daemon  96.62MB
Step 1/3 : FROM busybox
 ---> d8233ab899d4
Step 2/3 : COPY hello.txt .
COPY failed: stat /var/lib/docker/tmp/docker-builder375982663/hello.txt: no such file or directory
```
可以看出：
1. 镜像构建上下文路径并不是 Dockerfile 文件所在的路径；
2. Dockerfile 中指令的工作目录是服务端解压客户端传输的 tar 包的路径，因为 COPY 指令失败了，意味着当前目录并没有 hello.txt 文件。

# 五、总结
学习了 Docker 构建上下文，再也不会傻傻分不清 `.`的真实含义是什么了吧。同时我们也应该认识到，只有认真观察，多问为什么，然后多思考，才能深入的学好一个东西。让我们一起加油吧！

