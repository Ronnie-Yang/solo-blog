title: Python3安装之一键部署（centos7）
date: '2019-12-11 15:52:31'
updated: '2019-12-11 16:57:27'
tags: [Python, 自动化部署]
permalink: /articles/2019/12/11/1576050750912.html
---
![](https://img.hacpai.com/bing/20191010.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 
# O、前言
由于项目需要，我要在服务器上使用Python3.7的环境，但是centos7自带的是Python2.7，所以要自己再装一个Python3.7，一番摸索之后，写了一个一键部署的脚本。下面我就来一步步讲解一下过程。

# 一、基础工具和依赖包准备
安装`wget`工具和依赖包
```
yum -y install wget &&
yum -y groupinstall "Development tools" &&
yum -y install zlib-devel libffi-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel 
```
# 二、下载解压Python3.7
## 1、下载Python3.7
```
wget https://www.python.org/ftp/python/3.7.2/Python-3.7.2.tar.xz 
```
## 2、解压下载好的安装包
```
tar -xvJf  Python-3.7.2.tar.xz 
```
# 三、编译Python3.7
## 1、新建一个你要安装Python3的目录（我安装在/opt/python3）
```
mkdir /opt/python3
```

## 2、进入解压好的Python3.7.2目录中
```
cd Python-3.7.2
```

## 2、开始编译Python3
```
./configure --prefix=/opt/python3 &&
make &&
make install
```
参数`--prefix`指定的就是安装路径

# 四、创建软连接
```
ln -s /opt/python3/bin/python3 /usr/bin/python3 &&
ln -s /opt/python3/bin/pip3 /usr/bin/pip3
```
# 五、安装pip
```
yum -y install epel-release &&
yum -y install python-pip
```

# 六、创建虚拟环境
安装好了Python3，我们在使用的时候最好创建一个虚拟环境来使用，这样方便多个不同项目使用不同的环境。

## 1、安装 virtualenv 
```
python3 -m pip install virtualenv
```
## 2、创建Python3的虚拟环境
```
/opt/python3/bin/virtualenv  /opt/venv3
```

## 3、创建Python2的虚拟环境
有了Python3的虚拟环境，有时候我们原来的项目还需要使用Python2，那么也创建一个Python2的虚拟环境吧。

```
/opt/python3/bin/virtualenv -p /usr/bin/python2.7 /opt/venv2
```

# 七、总结
本文介绍了如何在centos7服务器上安装Python3并且创建Python虚拟环境。下面我就把整个过程的一键部署脚本贴出来啦，方便大家部署Python环境。


```  
yum -y install wget &&  
yum -y groupinstall "Development tools" &&  
yum -y install zlib-devel libffi-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel &&  
wget https://www.python.org/ftp/python/3.7.2/Python-3.7.2.tar.xz &&  
mkdir /opt/python3 &&  
tar -xvJf  Python-3.7.2.tar.xz &&  
cd Python-3.7.2 &&  
./configure --prefix=/opt/python3 &&  
make &&  
make install &&  
ln -s /opt/python3/bin/python3 /usr/bin/python3 &&  
ln -s /opt/python3/bin/pip3 /usr/bin/pip3 &&  
yum -y install epel-release &&  
yum -y install python-pip  &&
python3 -m pip install virtualenv &&
/opt/python3/bin/virtualenv  /opt/venv3 &&
/opt/python3/bin/virtualenv -p /usr/bin/python2.7 /opt/venv2
```
