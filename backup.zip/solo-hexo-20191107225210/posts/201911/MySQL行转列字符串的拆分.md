title: MySQL——行转列（字符串的拆分）
date: '2019-11-05 19:47:18'
updated: '2019-11-05 22:58:57'
tags: [数据库, MySQL]
permalink: /articles/2019/11/05/1572954438446.html
---
![](https://img.hacpai.com/bing/20181123.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

今天遇到一个MySQL的问题，需要将一个由逗号分隔的字符串拆分成多行，于是研究了一番。

---
## 原表结构
![图片.png](https://img.hacpai.com/file/2019/11/图片-3adcdc9c.png)

## 理想结果
![图片.png](https://img.hacpai.com/file/2019/11/图片-598803f8.png)
其实也就是在hive中常用的行转列的操作，但是在MySQL中没有现成的行转列的函数可以使用，那么就要想点其他的办法了。

这里先把实现的SQL贴出来，稍后再来讲原理。
## 实现SQL
```
select a.test_id, substring_index(substring_index(a.test_name, ',', b.help_topic_id+1), ',', -1) re_name
from test_tab a
join mysql.help_topic b
on b.help_topic_id < (length(a.test_name) - length(replace(a.test_name, ',', '')) +1)
order by a.test_id;
```
## 涉及的知识点
**一、字符串截取：substring_index(str,delim,count)**
* str：要处理的字符串
* delim：分隔符
* count：计数

如果 count 是正数，那么就是从左往右数，第N个分隔符的左边的全部内容；相反，count 如果是负数，那么就是从右边开始数，第N个分隔符右边的所有内容。如：
* ` substring_index('www.yanggongzi.top', '.', 1)` 的结果是：www
* ` substring_index('www.yanggongzi.top', '.', 2)` 的结果是：www.yanggongzi
* ` substring_index('www.yanggongzi.top', '.', -2)` 的结果是：yanggongzi.top

代码中的 `substring_index(substring_index(a.test_name, ',', b.help_topic_id+1), ',', -1) ` 就是表示截取 a.test_name 中分隔符切分后处于 b.help_topic_id+1 位置处的字符串。

**二、字符串替换：replace(str，str1，str2)**
* str：要处理的字符串
* str1：需要被替换掉的字符串
* str2：用于替换的新字符串

**三、字符串长度：length(str)**
* str：需要取长度值的字符串


## 重要提示
代码中关联了一个表 mysql.help_topic。这张表我们只用到了它的help_topic_id，可以看到这个help_topic_id是从0开始一直连续的，join这张表只是为了确定数据行数。

现在假设我的mysql.help_topic一只有5条数据，那么最多可转成5行数据，若果现在 test_name 分隔符切分后有6个就不能用mysql.help_topic这张表了。

由此看出我们完全可以找其他表来替代mysql.help_topic，只要满足表的id是连续的，且数据条数超过了你要转换的行数即可。一般使用某张表的自增id。

如果自增id是从1开始而不是从0开始的，那么最开始给出的SQL就应该做相应的修改。修改如下：
```
select a.test_id, substring_index(substring_index(a.test_name, ',', b.id), ',', -1) re_name
from test_tab a
join test_tab2 b
on b.id< (length(a.test_name) - length(replace(a.test_name, ',', '')) +2)
order by a.test_id;
```
---
好了，以上就是怎么将一行的字符串拆分成多行，实现行转列的全部过程了。如果还有更好的方式，请多留言讨论。
