title: Docker系列—04、使用 DockerFile 定制镜像
date: '2019-11-26 16:36:57'
updated: '2019-11-26 16:51:50'
tags: [Docker]
permalink: /Docker-study-04
---
![](https://gss2.bdstatic.com/9fo3dSag_xI4khGkpoWK1HF6hhy/baike/crop%3D0%2C156%2C1354%2C894%3Bc0%3Dbaike180%2C5%2C5%2C180%2C60/sign=c97c7c9b9b13b07ea9f20a4831e7bd12/f703738da977391281957edbf0198618377ae2dd.jpg) 

# O、前言
上一篇我们一起学习了如何使用 Docker 镜像，而我们使用的镜像都是来自于 Docker Hub 的，都是别人构建好的，虽然有些镜像制作得很好，可以拿来主义。但是作为一个梦想改变世界的人来说，总有自己的创意需要实现，那要怎么做呢？不要着急，现在我就带你来学习如何定制自己的镜像，让你的创意和想法能变成现实。

# 一、通过`docker commit`理解镜像构成
## 1、认识`docker commit`
镜像是容器的基础，每次执行 `docker run` 的时候都会指定哪个镜像作为容器运行的基础。我们知道，镜像是多层存储，每一层是在前一层的基础上进行的修改；而容器同样也是多层存储，是在以镜像为基础层，在其基础上加一层作为容器运行时的存储层。

docker commit 和 dockerfile 是定制镜像的两种方式。

现在我们用定制一个 web 服务器为例子，来讲解如何使用 docker commit 来定制镜像。
```
docker run --name webserver -d -p 8080:80 nginx
```
这条命令会用 `nginx` 镜像启动一个容器，命名为 `webserver`，并且映射了 8080 端口，这样我们可以用浏览器去访问这个 `nginx` 服务器。

我是在阿里云服务器上面做的实验，现在去访问我服务器的公网IP加上8080端口，我们会看到默认的 Nginx 欢迎页面。

![图片.png](https://img.hacpai.com/file/2019/11/图片-ebb75901.png)

现在我觉得这个页面太没创意了，我想把它改成我的欢迎页面，可以使用 `docker exec` 命令进入容器，修改这个页面的内容。
```
[root@yanggongzi ~]# docker exec -it webserver bash
root@d2051466d913:/# echo '<h1>Hello, YangGongZi!</h1>' > /usr/share/nginx/html/index.html
root@d2051466d913:/# exit
exit
```
我们以交互式终端方式进入 `webserver` 容器，并执行了 `bash` 命令，也就是获得一个可操作的 Shell。然后，我们用 `<h1>Hello, YangGongZi!</h1>` 覆盖了 `/usr/share/nginx/html/index.html` 的内容。

现在我们再刷新浏览器的话，会发现内容被改变了。

![图片.png](https://img.hacpai.com/file/2019/11/图片-0a2f4ade.png)

我们修改了容器的文件，也就是改动了容器的存储层。我们可以通过 `docker diff` 命令看到具体的改动。

```
[root@yanggongzi ~]# docker diff webserver
C /root
A /root/.bash_history
C /run
A /run/nginx.pid
D /run/secrets
C /usr/share/nginx/html/index.html
C /var/cache/nginx
D /var/cache/nginx/client_temp
D /var/cache/nginx/fastcgi_temp
D /var/cache/nginx/proxy_temp
D /var/cache/nginx/scgi_temp
D /var/cache/nginx/uwsgi_temp
```
以上这些就是我们定制好了的变化，我们希望能将其保存下来形成镜像，应该怎么办呢？

要知道，当我们运行一个容器的时候（如果不使用卷的话），我们做的任何文件修改都会被记录于容器存储层里。而 Docker 提供了一个 `docker commit` 命令，可以将容器的存储层保存下来成为镜像。换句话说，就是在原有镜像的基础上，再叠加上容器的存储层，并构成新的镜像。以后我们运行这个新镜像的时候，就会拥有原有容器最后的文件变化。

我们先来看看`docker commit` 的语法格式：

```
docker commit [选项] <容器ID或容器名> [<仓库名>[:<标签>]]
```
我们可以用下面的命令将前面我们更改过的容器保存为镜像：
```
[root@yanggongzi ~]# docker commit \
> --author "Ronnie_Yang <yanggongzi112@163.com>" \
> --message "修改欢迎首页" \
> webserver \
> nginx:v2
sha256:88b53cfb66d179e7f1cb01eeee68d96497c847c86caa554f05436f67802e4d7d
```
其中 `--author` 是指定修改的作者，而 `--message` 则是记录本次修改的内容。这点和 `git` 版本控制相似，不过这里这些信息可以省略留空。

我们可以在 `docker image ls` 中看到这个新定制的镜像：
```
[root@yanggongzi ~]# docker image ls
REPOSITORY             TAG                 IMAGE ID            CREATED             SIZE
nginx                  v2                  88b53cfb66d1        51 seconds ago      126 MB
docker.io/nginx        latest              231d40e811cd        3 days ago          126 MB
```
我们还可以用 `docker history` 具体查看镜像内的历史记录，如果比较 `nginx:latest` 的历史记录，我们会发现新增了我们刚刚提交的这一层。
```
[root@yanggongzi ~]# docker history nginx:v2
IMAGE               CREATED             CREATED BY                                      SIZE                COMMENT
88b53cfb66d1        2 minutes ago       nginx -g daemon off;                            119 B               修改欢迎首页
231d40e811cd        3 days ago          /bin/sh -c #(nop)  CMD ["nginx" "-g" "daem...   0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  STOPSIGNAL SIGTERM           0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  EXPOSE 80                    0 B                 
<missing>           3 days ago          /bin/sh -c ln -sf /dev/stdout /var/log/ngi...   22 B                
<missing>           3 days ago          /bin/sh -c set -x     && addgroup --system...   57.1 MB             
<missing>           3 days ago          /bin/sh -c #(nop)  ENV PKG_RELEASE=1~buster     0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  ENV NJS_VERSION=0.3.7        0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  ENV NGINX_VERSION=1.17.6     0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  LABEL maintainer=NGINX ...   0 B                 
<missing>           3 days ago          /bin/sh -c #(nop)  CMD ["bash"]                 0 B                 
<missing>           3 days ago          /bin/sh -c #(nop) ADD file:bc8179c87c8dbb3...   69.2 MB             
```

新的镜像定制好后，我们可以来运行这个镜像。

```
docker run --name web2 -d -p 8081:80 nginx:v2
```

这里我们命名为新的服务为 `web2`，并且映射到 `81` 端口。我们就可以直接访问看到结果，其内容应该和之前修改后的 `webserver` 一样。

至此，我们第一次完成了定制镜像，使用的是 `docker commit` 命令，手动操作给旧的镜像添加了新的一层，形成新的镜像，现在我们对镜像多层存储应该有了更直观的感觉。

## 2、慎用 `docker commit`
在上面的例子中我们可以看到，使用 `docker commit` 命令可以比较直观的帮助理解镜像分层存储的概念，也是一种比较方便的定制镜像的方式。但是实际环境中并不会这样使用。

首先，如果仔细观察之前的 `docker diff webserver` 的结果，你会发现除了真正想要修改的 `/usr/share/nginx/html/index.html` 文件外，但是由于我们是使用命令方式的执行，在修改了目标文件的同时还有很多文件被改动或添加了。这还仅仅是最简单的操作，如果是安装软件包、编译构建，那会有大量的无关内容被添加进来，如果不小心清理，将会导致镜像极为臃肿。

另外，使用 `docker commit` 意味着所有对镜像的操作都是黑箱操作，生成的镜像也被称为 **黑箱镜像**，换句话说，就是除了制作镜像的人知道执行过什么命令、怎么生成的镜像，别人根本无从得知。而且，过一段时间后就算是镜像的作者也无法记清具体的操作。虽然 `docker diff` 或许可以告诉得到一些线索，但是远远不到可以确保生成一致镜像的地步。这种黑箱镜像的维护工作是非常痛苦的。

而且，回顾之前提及的镜像所使用的分层存储的概念，除当前层外，之前的每一层都是不会发生改变的，换句话说，任何修改的结果仅仅是在当前层进行标记、添加、修改，而不会改动上一层。如果使用 `docker commit` 制作镜像，以及后期修改的话，每一次修改都会让镜像更加臃肿一次，所删除的上一层的东西并不会丢失，会一直如影随形的跟着这个镜像，即使根本无法访问到。这会让镜像更加臃肿。

# 二、使用 DockerFile 定制镜像
## 1、DockerFile 的概念
Docker 镜像是一个特殊的文件系统，除了提供容器运行时所需的程序、库、资源、配置等文件外，还包含了一些为运行时准备的一些配置参数（如匿名卷、环境变量、用户等）。镜像不包含任何动态数据，其内容在构建之后也不会被改变。

从刚才的 `docker commit` 的学习中，我们可以了解到，镜像的定制实际上就是定制每一层所添加的配置、文件。如果我们可以把每一层修改、安装、构建、操作的命令都写入一个脚本，用这个脚本来构建、定制镜像，那么之前提及的难以复现的问题、镜像构建透明性的问题、体积的问题就都会解决。这个脚本就是 Dockerfile。

Dockerfile 是一个文本文件，其内包含了一条条的指令(Instruction)，每一条指令构建一层，因此每一条指令的内容，就是描述该层应当如何构建。有了 Dockerfile，当我们需要定制自己额外的需求时，只需在 Dockerfile 上添加或者修改指令，重新生成 image 即可，省去了敲命令的麻烦。

## 2、DockerFile 的文件格式
我们先来看一看 Dockerfile 文件格式的样例：

```
##  Dockerfile文件格式

# This dockerfile uses the ubuntu image
# VERSION 2 - EDITION 1
# Author: docker_user
# Command format: Instruction [arguments / command] ..
 
# 1、第一行必须指定 基础镜像信息
FROM ubuntu
 
# 2、维护者信息
MAINTAINER Ronnie_Yang yanggongzi112@163.com
 
# 3、镜像操作指令
RUN echo "deb http://archive.ubuntu.com/ubuntu/ raring main universe" >> /etc/apt/sources.list
RUN apt-get update && apt-get install -y nginx
RUN echo "\ndaemon off;" >> /etc/nginx/nginx.conf
 
# 4、容器启动执行指令
CMD /usr/sbin/nginx
```
Dockerfile 分为四部分：
* 基础镜像信息
* 维护者信息
* 镜像操作指令
* 容器启动执行指令

一开始必须要指明所基于的镜像名称，接下来一般会说明维护者信息；后面则是镜像操作指令，例如 RUN 指令。每执行一条RUN 指令，镜像添加新的一层，并提交；最后是 CMD 指令，来指明运行容器时的操作命令。

## 3、DockerFile 的小例子

了解了 DockerFile 文件的格式，下面我们还以之前定制 `nginx` 镜像为例，这次我们使用 Dockerfile 来定制。

在一个空白目录中，建立一个文本文件，并命名为 `Dockerfile`，然后再文件中写入一下内容：
```
FROM nginx
RUN echo '<h1>Hello, YangGongZi !</h1>' > /usr/share/nginx/html/index.html
```
这个 Dockerfile 很简单，一共就两行。涉及到了两条指令，`FROM` 和 `RUN`。

## 4、构建镜像

有了 Dockerfile 文件。现在让我们来构建这个镜像吧。

这里我们需要使用 `docker build` 命令进行镜像构建。其格式为：

```
docker build [选项] <上下文路径/URL/->
```
在 `Dockerfile` 文件所在目录执行一下命令：
```
[root@yanggongzi dockerfiles]# docker build -t nginx:v3 .
Sending build context to Docker daemon 2.048 kB
Step 1/2 : FROM nginx
 ---> 231d40e811cd
Step 2/2 : RUN echo '<h1>Hello, YangGongZi !</h1>' > /usr/share/nginx/html/index.html
 ---> Running in b512ad709488
 ---> cd7b55273932
Removing intermediate container b512ad709488
Successfully built cd7b55273932
```
从命令的输出结果中，我们可以清晰的看到镜像的构建过程。在 `Step 2` 中，`RUN` 指令启动了一个容器 `9cdc27646c7b`，执行了所要求的命令，并最后提交了这一层 `44aa4490ce2c`，随后删除了所用到的这个容器 `9cdc27646c7b`。

在这里我们指定了最终镜像的名称 `-t nginx:v3`，构建成功后，我们可以像之前运行 `nginx:v2` 那样来运行这个镜像，其结果会和 `nginx:v2` 一样。

# 三、总结
这一篇文章，我们一起学习了定制 Docker 镜像的两种方法，同时也对镜像的分层存储模式也有了更深刻的理解。相信大家现在已经能够定制简单的镜像，来实现自己的创意了。

不过今天我们只是简单的学习了一下 DockerFile 以及镜像的构建，接下来我还会带大家一起来学习 DockerFile 的常用命令的详细使用方法，还有Docker镜像构建中的上下文问题。
